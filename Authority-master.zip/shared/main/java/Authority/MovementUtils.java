/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package Authority;

import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;

public final class MovementUtils extends MinecraftInstance {





    public static float getSpeed() {
        return (float) Math.sqrt(mc2.player.motionX * mc2.player.motionX + mc2.player.motionZ * mc2.player.motionZ);
    }

    public static void strafe() {
        strafe(getSpeed());
    }

    public static boolean isMoving() {
        return mc2.player != null && (mc2.player.movementInput.moveForward != 0F || mc2.player.movementInput.moveStrafe != 0F);
    }



    public static void strafe(final float speed) {
        if(!isMoving())
            return;

        final double yaw = getDirection();
        mc2.player.motionX = -Math.sin(yaw) * speed;
        mc2.player.motionZ = Math.cos(yaw) * speed;
    }

    public static void forward(final double length) {
        final double yaw = Math.toRadians(mc2.player.rotationYaw);
        mc2.player.setPosition(mc2.player.posX + (-Math.sin(yaw) * length), mc2.player.posY, mc2.player.posZ + (Math.cos(yaw) * length));
    }

    public static double getDirection() {
        float rotationYaw = mc2.player.rotationYaw;

        if(mc2.player.moveForward < 0F)
            rotationYaw += 180F;

        float forward = 1F;
        if(mc2.player.moveForward < 0F)
            forward = -0.5F;
        else if(mc2.player.moveForward > 0F)
            forward = 0.5F;

        if(mc2.player.moveStrafing > 0F)
            rotationYaw -= 90F * forward;

        if(mc2.player.moveStrafing < 0F)
            rotationYaw += 90F * forward;

        return Math.toRadians(rotationYaw);
    }
}