package Authority.time;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class TimeUtils {
    public static String getBeijingHour() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH");
        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        return dateFormat.format(new Date());
    }

    public static String getBeijingMinute() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("mm");
        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        return dateFormat.format(new Date());
    }

    public static String getBeijingSecond() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
        return dateFormat.format(new Date());
    }


}


