/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.event

import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase

open class Event

open class CancellableEvent : Event() {

    /**
     * Let you know if the event is cancelled
     *
     * @return state of cancel
     */
    class KillEntityEvent(val targetEntity: IEntityLivingBase) : Event()
    var isCancelled: Boolean = false
        private set

    /**
     * Allows you to cancel event
     */
    fun cancelEvent() {
        isCancelled = true
    }

}
class ShaderEvent : Event()
enum class EventState(val stateName: String) {
    PRE("PRE"), POST("POST")
}