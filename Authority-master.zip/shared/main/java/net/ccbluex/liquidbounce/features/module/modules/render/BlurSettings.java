/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import Authority.blur.GaussianBlur;
import Authority.blur.InGameBlurUtil;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.ShaderEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.ui.client.newdropdown.utils.render.StencilUtil;
import net.ccbluex.liquidbounce.utils.BloomUtil;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import Authority.blur.KawaseBloom;
import Authority.blur.KawaseBlur;
import net.ccbluex.liquidbounce.utils.render.tenacity.ColorUtil;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.shader.Framebuffer;

import java.awt.*;


@ModuleInfo(name = "BlurSettings", description = "Shader effect.", category = ModuleCategory.RENDER)
public class BlurSettings extends Module {
    public static final ListValue modeValues = new ListValue("BlurMode", new String[]{ "No","Rise","Tenacity","TenacityGlow", "New"}, "TenacityGlow");
    public static final ListValue mode = new ListValue("ShadowMode", new String[]{ "No","Tenacity","TenacityGlow", "New"}, "TenacityGlow");
    public static final BoolValue ArmorGlow =(BoolValue) new BoolValue("Armor Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue ArraylistGlow =(BoolValue) new BoolValue("Arraylist Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue SpeedGraphGlow =(BoolValue) new BoolValue("SpeedGraph Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue SessioninfoGlow =(BoolValue) new BoolValue("Sessioninfo Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue AutoPlayGGGlow = (BoolValue)new BoolValue("AutoPlayGG Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue logoGlow = (BoolValue) new BoolValue("LogoFix  Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue InventoryGlow =(BoolValue) new BoolValue("Inventory Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue KeyBindsGlow =(BoolValue) new BoolValue("KeyBinds Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue EffectsGlow= (BoolValue) new BoolValue("Effects  Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue NotificationsGlow =(BoolValue) new BoolValue("Notifications Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue ScoreboardGlow =(BoolValue) new BoolValue("Scoreboard Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue RadarGlow = (BoolValue) new BoolValue("Radar Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue Glow = (BoolValue) new BoolValue("ESP2D Tags Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final BoolValue TargetHudGlow = (BoolValue) new BoolValue("TargetHud  Glow", true).displayable(() -> mode.get().equals("TenacityGlow")&&modeValues.get().equals("TenacityGlow"));
    public static final IntegerValue hudradius =  new IntegerValue("HUD BlurUtils Radius", 5, 1, 50 );
    private final IntegerValue shadowRadius2= (IntegerValue) new IntegerValue("Tenacity Bloom Iterations", 2, 1, 8).displayable(() -> mode.get().equals("Tenacity")||mode.get().equals("TenacityGlow"));
    private final IntegerValue  tshadowOffset = (IntegerValue) new IntegerValue("Tenacity Bloom Offset", 3, 1, 10).displayable(() -> mode.get().equals("Tenacity") || mode.get().equals("New")||mode.get().equals("TenacityGlow"));
    public static final IntegerValue iterations = (IntegerValue) new IntegerValue("Tenacity Blur Iterations", 3, 1, 8).displayable(() -> modeValues.get().equals("Tenacity")||mode.get().equals("TenacityGlow"));
    public static final IntegerValue offset = (IntegerValue) new IntegerValue("Tenacity Blur Offset", 2, 1, 10).displayable(() -> modeValues.get().equals("Tenacity")||mode.get().equals("TenacityGlow"));

    public  static final IntegerValue radius = (IntegerValue) new IntegerValue("Blur Radius", 5, 1, 50 ).displayable(() -> modeValues.get().equals("Rise") || modeValues.get().equals("New"));

    private final IntegerValue shadowRadius=(IntegerValue)  new IntegerValue("ShadowRadius", 6, 1, 20).displayable(() -> mode.get().equals("New"));
    private final IntegerValue  shadowOffset = (IntegerValue) new IntegerValue("ShadowOffset", 2, 1, 10).displayable(() -> mode.get().equals("New"));

    private Framebuffer bloomFramebuffer = new Framebuffer(1, 1, true);
    private float saturation = 1;
    private int speed = 15;

    public Color getColor(int index) {
        return ColorUtil.rainbow(speed, index, saturation, 1, 1);
    }
    @Expose
    @SerializedName("toggled")
    protected boolean toggled;
    public void toggleSilent() {
        this.toggled = !this.toggled;
        if (this.toggled) {
            this.onEnable();
        } else {
            this.onDisable();
        }
    }

    public BlurSettings() {
        if (!toggled) this.toggleSilent();
    }

    private String currentMode;

    @Override
    public void onEnable() {

        super.onEnable();
    }

    public static void stuffToBlur(boolean bloom) {
    }
    public static void stuffToBlur2(boolean bloom) {

    }
    public void blurScreen() {
        if (!toggled) return;
            switch (modeValues.get()) {
                case "Rise":
                    InGameBlurUtil.toBlurBuffer.bindFramebuffer(false);
                    InGameBlurUtil.setupBuffers();
                    //InGameBlurUtil.renderGaussianBlur((float) ((NumberSetting) Objects.requireNonNull(Rise.INSTANCE.getModuleManager().getSetting("Blur", "Radius"))).getValue(), (float) ((NumberSetting) Objects.requireNonNull(Rise.INSTANCE.getModuleManager().getSetting("Blur", "Compression"))).getValue(), true, false);
                    InGameBlurUtil.renderGaussianBlur(radius.getValue().floatValue(), 2, true, false);
                    mc.getFramebuffer().bindFramebuffer(false);
                        break;
            case "New":
                    StencilUtil.initStencilToWrite();
                    LiquidBounce.eventManager.callEvent(new ShaderEvent());

                    stuffToBlur(false);
                    stuffToBlur2(false);
                    bloomFramebuffer.unbindFramebuffer();
                    StencilUtil.readStencilBuffer(1);
                    GaussianBlur.renderBlur(radius.getValue().floatValue());
                    StencilUtil.uninitStencilBuffer();
                        break;
                case "Tenacity":
                    bloomFramebuffer = RenderUtils.TcreateFrameBuffer(bloomFramebuffer);
                    bloomFramebuffer.framebufferClear();
                    bloomFramebuffer.bindFramebuffer(false);
                    LiquidBounce.eventManager.callEvent(new ShaderEvent());
                    stuffToBlur2(false);
                    stuffToBlur(false);
                    bloomFramebuffer.unbindFramebuffer();
                    KawaseBlur.renderBlur(bloomFramebuffer.framebufferTexture, iterations.getValue(), offset.getValue());
                        break;
                case "TenacityGlow":
                    bloomFramebuffer = RenderUtils.TcreateFrameBuffer(bloomFramebuffer);
                    bloomFramebuffer.framebufferClear();
                    bloomFramebuffer.bindFramebuffer(false);
                    LiquidBounce.eventManager.callEvent(new ShaderEvent());
                    stuffToBlur2(false);
                    stuffToBlur(false);
                    bloomFramebuffer.unbindFramebuffer();
                    KawaseBlur.renderBlur2(bloomFramebuffer.framebufferTexture, iterations.getValue(), offset.getValue());
                    break;
                case "No":
                    break;
             }

            switch (mode.get()) {
                case "New":
                    bloomFramebuffer = RenderUtils.createFrameBuffer(bloomFramebuffer);
                    bloomFramebuffer.framebufferClear();
                    bloomFramebuffer.bindFramebuffer(true);
                    LiquidBounce.eventManager.callEvent(new ShaderEvent());
                    bloomFramebuffer.unbindFramebuffer();
                    BloomUtil.renderBlur(bloomFramebuffer.framebufferTexture, shadowRadius.get(), shadowOffset.get());
                        break;
                case "Tenacity":
                    bloomFramebuffer = RenderUtils.TcreateFrameBuffer(bloomFramebuffer);
                    bloomFramebuffer.framebufferClear();
                    bloomFramebuffer.bindFramebuffer(false);
                    LiquidBounce.eventManager.callEvent(new ShaderEvent());
                    stuffToBlur(true);
                    bloomFramebuffer.unbindFramebuffer();
                    KawaseBloom.renderBlur(bloomFramebuffer.framebufferTexture, shadowRadius2.getValue(), tshadowOffset.getValue());
                    break;
                case "TenacityGlow":
                    bloomFramebuffer = RenderUtils.TcreateFrameBuffer(bloomFramebuffer);
                    bloomFramebuffer.framebufferClear();
                    bloomFramebuffer.bindFramebuffer(false);
                    LiquidBounce.eventManager.callEvent(new ShaderEvent());
                    stuffToBlur(true);
                    bloomFramebuffer.unbindFramebuffer();
                    KawaseBloom.renderBlur2(bloomFramebuffer.framebufferTexture, shadowRadius2.getValue(), tshadowOffset.getValue());
                    break;
                case "No":
                    break;
            }
    }
}
