/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module

import net.ccbluex.liquidbounce.ui.client.newdropdown.utils.objects.Drag
import net.ccbluex.liquidbounce.ui.client.newdropdown.utils.render.Scroll

enum class ModuleCategory(val displayName: String) {

    COMBAT("Combat"),
    PLAYER("Player"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    WORLD("World"),
    MISC("Misc"),
    EXPLOIT("Exploit"),
    AUTHORITY("Authority");


    private val drag: Drag? = null

    open fun getDrag(): Drag? {
        return drag
    }

    private val scroll = Scroll()

    open fun getScroll(): Scroll? {
        return scroll
    }
}