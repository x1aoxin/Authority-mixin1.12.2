package net.ccbluex.liquidbounce.features.module.modules.Authority

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "Authority", description = "WUDI" ,category = ModuleCategory.AUTHORITY)
class XiaxinYYDS : Module(){
    /**
     */
    // Mode
    private val modeValue = ListValue("Mode", arrayOf("YYDS","WUDI","Group：854798131"), "Group：854798131")

    override val tag: String?
        get() = modeValue.get()
}