package net.ccbluex.liquidbounce.features.module.modules.Authority

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.server.SPacketChat
import java.util.regex.Pattern

@ModuleInfo(name = "AntiFakePlayer", description = "Fix", category = ModuleCategory.AUTHORITY)
class AntiFakePlayer : Module() {

    private val mode = ListValue("Mode", arrayOf("4v4/2v2/1v1", "BWXP32", "BWXP16"), "4V4/2v2/1V1")
    private val logMode = ListValue("LogStyle", arrayOf("RyFNew","FDPClientAntibot","NullClient", "Normal", "Old"), "Normal")
    private val msg = BoolValue("ShowChatMessage", false)
    private val hideantigetname = BoolValue("TryHideAntiGetname", false)
    private val showHideChat = BoolValue("ShowHideChat", false)

    private var bots = 0
    override fun onDisable() {
        bots = 0
        clearAll()
        super.onDisable()
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        if ((packet is SPacketChat) && !packet.chatComponent.unformattedText.contains(":") && (packet.chatComponent.unformattedText.startsWith("起床战争") || packet.chatComponent.unformattedText.startsWith("[起床战争"))) {
            val chat = packet.chatComponent.unformattedText
            when (mode.get().toLowerCase()) {
                "4v4/2v2/1v1" -> {
                    val matcher = Pattern.compile("杀死了 (.*?)\\(").matcher(chat)
                    val matcher2 = Pattern.compile("起床战争>> (.*?) (\\(((.*?)死了!))").matcher(chat)
                    if (matcher.find()) {
                        val name = matcher.group(1).trim()
                        if (name != "") {
                            botchange(name, 4988)
                        }
                    }
                    if (matcher2.find()) {
                        val name = matcher2.group(1).trim()
                        if (name != "") {
                            botchange(name, 4988)
                        }
                    }
                }

                "bwxp32" -> {
                    val matcher = Pattern.compile("杀死了 (.*?)\\(").matcher(chat)
                    val matcher2 = Pattern.compile("起床战争 >> (.*?) (\\(((.*?)死了!))").matcher(chat)
                    if (matcher.find()) {
                        val name = matcher.group(1).trim()
                        if (name != "") {
                            botchange(name, 7400)
                        }
                    }
                    if (matcher2.find()) {
                        val name = matcher2.group(1).trim()
                        if (name != "") {
                            botchange(name, 4988)
                        }
                    }
                }

                "bwxp16" -> {
                    val matcher = Pattern.compile("击败了 (.*?)!").matcher(chat)
                    val matcher2 = Pattern.compile("玩家 (.*?)死了！").matcher(chat)
                    if (matcher.find()) {
                        val name = matcher.group(1).trim()
                        if (name != "") {
                            botchange(name, 10000)
                        }
                    }
                    if (matcher2.find()) {
                        val name = matcher2.group(1).trim()
                        if (name != "") {
                            botchange(name, 10000)
                        }
                    }
                }
            }
        }
        if (packet is SPacketChat && packet.chatComponent.unformattedText.contains(
                ":") && !packet.chatComponent.unformattedText.contains(
                mc.thePlayer!!.displayNameString) && (packet.chatComponent.unformattedText.contains(
                "起床战争") && !packet.chatComponent.unformattedText.contains(
                "01:00:00 是这个地图的记录!") && !packet.chatComponent.unformattedText.contains(
                "之队队设置一个新的记录:")
                    )) {
            if (hideantigetname.get()) {
                event.cancelEvent()
                if (showHideChat.get()) ClientUtils.displayChatMessage("§b${LiquidBounce.CLIENT_NAME} §7» §c隐藏了AntiGetname消息。")
            }
        }
    }

    @EventTarget
    fun onWorld(event: WorldEvent?) {
        clearAll()
    }

    private fun botchange(name: String, cooldown: Long) {
        bots++
        LiquidBounce.fileManager.friendsConfig.addFriend(name)
        if (msg.get()) {
            botlog(name, "add")
        }
        Thread {
            try {
                Thread.sleep(cooldown)
                LiquidBounce.fileManager.friendsConfig.removeFriend(name)
                bots--
                if (msg.get()) {
                    botlog(name, "remove")
                }
            } catch (ex: InterruptedException) {
                ex.printStackTrace()
            }
        }.start()
    }

    private fun botlog(name: String, mode: String) {
        when (mode.toLowerCase()) {
            "add" -> {
                when (logMode.get().toLowerCase()) {
                    "ryfnew" -> {
                        ClientUtils.displayChatMessage("§b${LiquidBounce.CLIENT_NAME} §7» §aAdded§f HYT Bot §7-> §e$name")
                    }
                    "normal" -> {
                        ClientUtils.displayChatMessage("§7[§6${LiquidBounce.CLIENT_NAME}§7] §fAdded HYT Bot: §7$name")
                    }
                    "old" -> {
                        ClientUtils.displayChatMessage("§8[§c§l${LiquidBounce.CLIENT_NAME}提醒您§8] §d添加无敌人：§7$name")
                    }
                    "fdpclientantibot" -> {
                        ClientUtils.displayChatMessage("§7[§cAntiBot§7] §fAdded §7$name§f due to it being a bot.")
                    }
                    "nullclient" -> {
                        ClientUtils.displayChatMessage("§7[§cAntiBots§7] §fAdded a bot(§7$name§f)")
                    }
                }
            }
            "remove" -> {
                when (logMode.get().toLowerCase()) {
                    "ryfnew" -> {
                        ClientUtils.displayChatMessage("§b${LiquidBounce.CLIENT_NAME} §7» §cRemoved§f HYT Bot §7-> §e$name")
                    }
                    "normal" -> {
                        ClientUtils.displayChatMessage("§7[§6${LiquidBounce.CLIENT_NAME}§7] §fRemoved HYT Bot: §7$name")
                    }
                    "old" -> {
                        ClientUtils.displayChatMessage("§8[§c§l${LiquidBounce.CLIENT_NAME}提醒您§8] §d删除无敌人：§7$name")
                    }
                    "fdpclientantibot" -> {
                        ClientUtils.displayChatMessage("§7[§cAntiBot§7] §fRemoved §7$name§f due to respawn.")
                    }
                    "nullclient" -> {
                        ClientUtils.displayChatMessage("§7[§cAntiBots§7] §fRemoved a bot(§7$name§f)")
                    }
                }
            }
        }
    }


    private fun clearAll() {
        LiquidBounce.fileManager.friendsConfig.clearFriends()
    }

    override val tag: String
        get() = (mode.get())
}