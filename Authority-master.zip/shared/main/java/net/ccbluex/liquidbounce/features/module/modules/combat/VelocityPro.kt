/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.api.minecraft.client.block.IBlock
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import kotlin.jvm.internal.Intrinsics
import kotlin.math.cos
import kotlin.math.sin

@ModuleInfo(name = "VelocityPro", description = "Skid.", category = ModuleCategory.COMBAT)
class VelocityPro: Module() {
        /**
         * OPTIONS
         */
        private val horizontalValue = FloatValue("Horizontal", 0F, 0F, 1F)
        private val verticalValue = FloatValue("Vertical", 0F, 0F, 1F)
        private val modeValue = ListValue(
                "Mode", arrayOf(
                        "Jump", "GrimVelocity", "Authority"
                ), "GrimVelocity"
        )
        private val newaac4XZReducerValue = FloatValue("NewAAC4XZReducer", 0.45F, 0F, 1F)

        private val velocityTickValue = IntegerValue("VelocityTick", 1, 0, 10)

        // Reverse
        private val reverseStrengthValue = FloatValue("ReverseStrength", 1F, 0.1F, 1F)
        private val reverse2StrengthValue = FloatValue("SmoothReverseStrength", 0.05F, 0.02F, 0.1F)

        private val hytpacketaset = FloatValue("HytPacketASet", 0.35F, 0.1F, 1F)
        private val hytpacketbset = FloatValue("HytPacketBSet", 0.5F, 1F, 1F)

        // AAC Push
        private val aacPushXZReducerValue = FloatValue("AACPushXZReducer", 2F, 1F, 3F)
        private val aacPushYReducerValue = BoolValue("AACPushYReducer", true)
        public var block: IBlock? = null
        private val noFireValue = BoolValue("noFire", false)
        private val hytGround = BoolValue("HytOnlyGround", true)

        //Custom
        private val customX = FloatValue("CustomX", 0F, 0F, 1F)
        private val customYStart = BoolValue("CanCustomY", false)
        private val customY = FloatValue("CustomY", 1F, 1F, 2F)
        private val customZ = FloatValue("CustomZ", 0F, 0F, 1F)
        private val customC06FakeLag = BoolValue("CustomC06FakeLag", false)


        /**
         * VALUES
         */

        private var huayutingjumpflag = false
        private var velocityTimer = MSTimer()
        private var
                velocityInput = false
        private var canCleanJump = false
        private var velocityTick = 0

        // SmoothReverse
        private var reverseHurt = false

        // AACPush
        private var jump = false
        private var canCancelJump = false
        override val tag: String
                get() = modeValue.get()

        override fun onDisable() {
                mc.thePlayer?.speedInAir = 0.02F
        }

        @EventTarget
        private fun onUpdate(event: UpdateEvent) {
                val thePlayer = mc.thePlayer ?: return

                if (thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
                        return

                if (noFireValue.get() && mc.thePlayer!!.burning) return
                when (modeValue.get().toLowerCase()) {

                        "authority" -> {
                                if (mc.thePlayer == null) Intrinsics.throwNpe()
                                if (mc.thePlayer!!.onGround) {
                                        if (mc.thePlayer == null) Intrinsics.throwNpe()
                                        if (mc.thePlayer!!.hurtTime > 0) {
                                                if (mc.thePlayer == null) Intrinsics.throwNpe()
                                                if (mc.thePlayer!!.motionX != 0.0) {
                                                        if (mc.thePlayer == null) Intrinsics.throwNpe()
                                                        if (mc.thePlayer!!.motionZ != 0.0) {
                                                                if (mc.thePlayer == null) Intrinsics.throwNpe()
                                                                mc.thePlayer!!.onGround = true
                                                        }
                                                }
                                        }
                                        if (mc.thePlayer == null) Intrinsics.throwNpe()
                                        if (mc.thePlayer!!.hurtResistantTime > 0) {
                                                if (mc.thePlayer == null) Intrinsics.throwNpe()
                                                mc.thePlayer!!.motionY = mc.thePlayer!!.motionY - 0.014999993
                                        }
                                        if (mc.thePlayer == null) Intrinsics.throwNpe()
                                        if (mc.thePlayer!!.hurtResistantTime >= 19) {
                                                if (mc.thePlayer == null) Intrinsics.throwNpe()
                                                mc.thePlayer!!.motionX = mc.thePlayer!!.motionX / 1.5f
                                                if (mc.thePlayer == null) Intrinsics.throwNpe()
                                                mc.thePlayer!!.motionZ = mc.thePlayer!!.motionZ / 1.5f
                                        }
                                }
                        }


                        "GrimVelocity" -> {

                                if (mc.thePlayer == null)
                                        Intrinsics.throwNpe()
                                if (mc2.player.onGround) {
                                        if (mc.thePlayer == null)
                                                Intrinsics.throwNpe();
                                        if (mc2.player.hurtTime > 0) {
                                                thePlayer.motionX += -1.0E-7
                                                thePlayer.motionY += -1.0E-7
                                                thePlayer.motionZ += -1.0E-7
                                                thePlayer.isAirBorne = true
                                        }
                                }
                        }

                        "jump" -> if (thePlayer.hurtTime > 0 && thePlayer.onGround) {
                                thePlayer.motionY = 0.42

                                val yaw = thePlayer.rotationYaw * 0.017453292F

                                thePlayer.motionX -= sin(yaw) * 0.2
                                thePlayer.motionZ += cos(yaw) * 0.2
                        }


                }


        }

        @EventTarget
        private fun onBlockBB(event: BlockBBEvent) {
                block = event.block
        }

        @EventTarget
        private fun onPacket(event: PacketEvent) {
                val thePlayer = mc.thePlayer ?: return

                val packet = event.packet

                if (classProvider.isSPacketEntityVelocity(packet)) {
                        val packetEntityVelocity = packet.asSPacketEntityVelocity()


                        if (noFireValue.get() && mc.thePlayer!!.burning) return
                        if ((mc.theWorld?.getEntityByID(packetEntityVelocity.entityID) ?: return) != thePlayer)
                                return

                        velocityTimer.reset()

                        when (modeValue.get().toLowerCase()) {


                        }

                }
        }

        @EventTarget
        private fun onJump(event: JumpEvent) {
                val thePlayer = mc.thePlayer

                if (thePlayer == null || thePlayer.isInWater || thePlayer.isInLava || thePlayer.isInWeb)
                        return

                when (modeValue.get().toLowerCase()) {


                }
        }
}
