package net.ccbluex.liquidbounce.features.module.modules.Authority


import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.*
import net.ccbluex.liquidbounce.features.module.modules.player.InventoryCleaner
import net.ccbluex.liquidbounce.features.module.modules.world.ChestStealer
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.management.CombatManager
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue
import net.ccbluex.liquidbounce.value.TextValue
import net.minecraft.network.play.server.SPacketChat
import java.util.regex.Pattern
@ModuleInfo(name = "AutoGG", category = ModuleCategory.AUTHORITY, description = "Auto GG")
class AutoGG : Module() {

    private val modeValue = ListValue("Server", arrayOf( "HuaYuTingBW","HuaYuTingSw","HuaYuTing16","no"), "HuaYuTingBW")
    private val autodis = BoolValue("Auto-Disable",true)
    private val Text = BoolValue("TextBoolValue",true)
    private val Sound = BoolValue("Sound",true)
    private val prefix = BoolValue("@",true)
    private val textValue = TextValue("Text", "[Authority]GG")
    var totalPlayed = 0
    var AutoPlayGG = false
    var win = 0
    var ban = 0
    @EventTarget
    fun onPacket(event: PacketEvent) {

        val GrimVelocity = LiquidBounce.moduleManager.getModule(GrimVelocity::class.java) as GrimVelocity
        val KillAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura

        val Velocity = LiquidBounce.moduleManager.getModule(Velocity::class.java) as Velocity
        val ChestStealer = LiquidBounce.moduleManager.getModule(ChestStealer::class.java) as ChestStealer
        val InventoryCleaner = LiquidBounce.moduleManager.getModule(InventoryCleaner::class.java) as InventoryCleaner
        val AutoArmor = LiquidBounce.moduleManager.getModule(AutoArmor::class.java) as AutoArmor
        val packet = event.packet.unwrap()
        if (packet is SPacketChat) {
            val text = packet.chatComponent.unformattedText
            if(packet is SPacketChat){
                val matcher = Pattern.compile("玩家(.*?)在本局游戏中行为异常").matcher(packet.chatComponent.unformattedText)
                if(matcher.find()){
                    ban ++
                    val banname = matcher.group(1)
                    LiquidBounce.hud.addNotification(
                        Notification("BanChecker","$banname was banned. (banned:$ban)",
                            NotifyType.INFO, animeTime = 1000)
                    )
                }
            }
        }
        if (packet is SPacketChat) {
            val text = packet.chatComponent.unformattedText
            when (modeValue.get().toLowerCase()) {
                "huayutingbw" -> {
                    if (text.contains("      喜欢      一般      不喜欢", true)) {
                        if (Text.get()) {
                            mc.thePlayer!!.sendChatMessage((if (prefix.get()) "@" else "")+textValue.get())
                        }
                        win += 1
                        AutoPlayGG =true
                        LiquidBounce.hud.addNotification(Notification("AutoPlay", "恭喜胜利！", NotifyType.INFO))
                        if (autodis.get()) {
                            KillAura.state = false

                            Velocity.state = false
                            GrimVelocity.state = false
                        }
                    }
                    if (text.contains("起床战争>> 游戏开始 ...", true)) {
                        totalPlayed ++
                        LiquidBounce.hud.addNotification(Notification("AutoPlay", "游戏开始！！", NotifyType.INFO))
                    }
                }
                "huayuting16" -> {
                    if (text.contains("[起床战争] Game 结束！感谢您的参与！", true)) {
                        LiquidBounce.hud.addNotification(Notification("AutoPlay","Game Over", NotifyType.INFO))
                        if (Text.get()) {
                            mc.thePlayer!!.sendChatMessage((if (prefix.get()) "@" else "")+textValue.get())
                        }
                        win += 1
                        if (autodis.get()) {
                            KillAura.state = false

                            GrimVelocity.state = false
                            Velocity.state = false
                        }
                    }
                }
                "huayutingsw" -> {

                    val matcher = Pattern.compile("你在地图(.*?)中赢得了(.*?)").matcher(packet.chatComponent.unformattedText)
                    if (text.contains("开始倒计时: 1 秒", true)) {
                        totalPlayed++
                        LiquidBounce.moduleManager[net.ccbluex.liquidbounce.features.module.modules.world.ChestStealer::class.java].state = true
                        LiquidBounce.moduleManager[InventoryCleaner::class.java].state = true
                        LiquidBounce.hud.addNotification(Notification("AutoPlay", "游戏开始！！", NotifyType.INFO))
                    }
                    if (text.contains("你现在是观察者状态. 按E打开菜单.", true)) {
                        if (autodis.get()) {
                            KillAura.state = false

                            Velocity.state = false
                            GrimVelocity.state = false
                            ChestStealer.state = false
                            InventoryCleaner.state = false
                        }
                    }
                    if (matcher.find()) {
                        LiquidBounce.hud.addNotification(Notification("AutoPlay","Game Over", NotifyType.INFO))
                        if (Text.get()) {
                            mc.thePlayer!!.sendChatMessage((if (prefix.get()) "@" else "")+textValue.get())
                        }
                        if (autodis.get()) {
                            KillAura.state = false
                            Velocity.state = false
                            GrimVelocity.state = false
                            ChestStealer.state = false
                            InventoryCleaner.state = false
                        }
                        win += 1
                    }
                }
            }
        }
    }
    override fun handleEvents() = true
    override val tag: String
        get() = modeValue.get()
}
