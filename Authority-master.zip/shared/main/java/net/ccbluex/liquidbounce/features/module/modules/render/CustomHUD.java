package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.event.ShaderEvent;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.render.RoundedUtil;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;

@ModuleInfo(name = "CustomHUD" , description = "CustomHUD." , category = ModuleCategory.RENDER)
public class CustomHUD extends Module {
    public static final ListValue shader = new ListValue("ShaderMode", new String[]{"Moon","Dicks","Day"}, "Moon");
    public static final ListValue drawMode = new ListValue("Round", new String[]{"Rect","Round"}, "Moon");
    public static final BoolValue Chinese = new BoolValue("ChineseTargetHUD", false);
    public static final BoolValue ChineseScore = new BoolValue("ChineseScore", false);
    public static final BoolValue Hotbarblur = new BoolValue("HotbarBlur", false);
    public CustomHUD() {
        setState(true);
    }
    @EventTarget
    public void onShader (final ShaderEvent event){

        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        if (LiquidBounce.INSTANCE.getHeight() != -14){
            RoundedUtil.drawRound(6,scaledResolution.getScaledHeight() - ((LiquidBounce.INSTANCE.getHeight() + 63)),340,
                    LiquidBounce.INSTANCE.getHeight() + 10,CustomColor.ra.get(),
                    new Color(0,0,0,60));
        }
    }
    @EventTarget
    public void onRender2D(final Render2DEvent event) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        if (LiquidBounce.INSTANCE.getHeight() != -14){
            RoundedUtil.drawRound(6,scaledResolution.getScaledHeight() - ((LiquidBounce.INSTANCE.getHeight() + 63)),340,
                    LiquidBounce.INSTANCE.getHeight() + 10,CustomColor.ra.get(),
                    new Color(0,0,0,60));
        }
    }
}
